﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace Blackjack
{
    public class Program
    {

        public static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.Title = "Joe's Blackjack Game";
            int selection = 0;
            bool check = false;
            string[] options = new string[3] { "1. Play Blackjack", "2. Shuffle and Show Deck", "3. Exit" };
            Console.SetWindowSize(132, 42);

            while (!check)
            {
                //calls ReadChoic to print menu and get selection
                ReadChoice("Choice: ", options, out selection);
                try
                {
                    switch (selection)
                    {
                        case 1://play blackjack
                            #region Game Loop and Variables
                            Console.Clear();
                            bool loop = true;
                            string answere = string.Empty;
                            PlayRound();

                            //game loop
                            while (loop)
                            {
                                Console.WriteLine("Play again(Y/N)? "); //askes user if they want to play again
                                answere = Console.ReadLine();
                                if (answere.ToLower() == "y")
                                {
                                    //call play round method and clears console
                                    Console.Clear();
                                    PlayRound();
                                }
                                else if (answere.ToLower() == "n")
                                {
                                    //clears console and breaks out of loop and goes back to main menu
                                    Console.Clear();
                                    loop = false; //breaks out loop
                                }
                                else
                                {
                                    //writes out invalid input if user enters anything besides y or n
                                    Console.WriteLine("Invalid Input. Please enter Y/y or N/n.");
                                }
                            }
                            #endregion
                            break;
                        case 2://shuffle and show deck
                            #region Shuffle and Show deck
                            Console.Clear();
                            Deck deckInstant = new Deck();
                            deckInstant.Shuffle();
                            for (int i = 10; i < 50; i += 10) //y axis 
                            {
                                for (int j = 0; j < 130; j += 10) //x axis/spaces
                                {
                                    deckInstant.Deal().Draw(j, i);
                                }
                            }
                            Console.WriteLine();
                            #endregion
                            break;
                        case 3://exit
                            Environment.Exit(0);
                            break;
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Error System Crash.");
                }
            }
        }
        public static void ReadChoice(string prompt, string[] options, out int selection)
        {
            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine(options[i]);
            }
            Console.Write(prompt);
            selection = ReadInteger("Choice: ", 1, 3);

        }
        public static int ReadInteger(string prompt, int min, int max)
        {
            int num = 0;
            bool test = false;

            while (!test)
            {
                try
                {
                    num = Convert.ToInt32(Console.ReadLine());
                    if (num >= min && num <= max)
                    {
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input! Enter a number between 1-3.");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    }
                }
                catch (Exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error! Not a number, Please enter a number.");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write(prompt);
                }
            }
            return num;
        }
        public static void PlayRound()
        {
            #region Variables & Instances
            Deck deckInst = new Deck();
            BlackJackHand dealer = new BlackJackHand();
            BlackJackHand player = new BlackJackHand();
            deckInst.Shuffle(); //shuffles cards
            ICard card;
            int hitOrStand = 0;
            int x = 0; //variable for dealer draw x
            int x2 = 0; //variable for player draw x
            #endregion

            Console.WriteLine("Dealer Score: x"); //hides dealers score

            #region 2 initial cards
            for (int i = 0; i < 2; i++) //deal initial 2 cards for dealer
            {
                dealer.AddCard(card = deckInst.Deal()); //adds card to dealer hand
                dealer.IsDealer = true; //sets isdealer to true so first card can be covered
                card.Draw(x, 2); //draws card
                dealer.Draw(0, 0); //covers first card
                x += 10; //moves card over 10 spaces each draw
            }

            for (int j = 0; j < 2; j++)  //deals initial 2 cards for player
            {
                player.AddCard(card = deckInst.Deal()); //adds card to players hand
                card.Draw(x2, 12); //draws card
                x2 += 10; //moves card over 10 spaces each draw
            }
            Console.SetCursorPosition(0, 10);
            Console.WriteLine($"Player Score: {player.Score}"); //updates score for first 2 cards
            #endregion

            #region Players Turn
            //players turn
            while (player.Score < 21)
            {
                try
                {
                    //writes out hit or stand text and reads input
                    Console.SetCursorPosition(0, 18);
                    Console.WriteLine("Hit(1) or Stand(2)");
                    Console.WriteLine(' ');
                    Console.SetCursorPosition(Console.CursorLeft, Console.CursorTop - 1);
                    hitOrStand = Convert.ToInt32(Console.ReadLine());

                    if (hitOrStand == 1)
                    {
                        //clears exception message
                        Console.SetCursorPosition(0, 20);
                        Console.WriteLine("                                             ");
                        //draw another card
                        player.AddCard(card = deckInst.Deal()); //adds card to players hand
                        card.Draw(x2, 12); //draws card
                        x2 += 10; //moves card over 10 spaces each draw
                    }
                    else if (hitOrStand == 2)
                    {
                        //clears exception message
                        Console.SetCursorPosition(0, 20);
                        Console.WriteLine("                                             ");
                        //clears line where hit or stand text is
                        Console.SetCursorPosition(0, 18);
                        Console.WriteLine("                   "); 
                        break; //breaks out of player loop
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Invalid Input. Please Enter 1 or 2.");
                }
                
                Console.SetCursorPosition(0, 10);
                Console.WriteLine($"Player Score: {player.Score}"); //updates player score after each card is drawn
            }//end player while loop
            #endregion

            dealer.IsDealer = false; //sets IsDealer to false so card can be unhidden
            dealer.Draw(0, 0); //uncovers first card

            #region Dealers Turn
            //dealers round
            while (dealer.Score < 17 && player.Score <= 21)
            {
                Console.SetCursorPosition(0, 0);
                dealer.AddCard(card = deckInst.Deal()); //adds card to dealer hand
                card.Draw(x, 2); //draws card
                x += 10;
            }//end dealer loop  

            Console.SetCursorPosition(0, 0);
            Console.WriteLine($"Dealer Score: {dealer.Score}"); //updates dealer score for cards drawn
            #endregion

            #region win/lose conditions
            //WIN/LOSE CONDITIONS
            if (dealer.Score == player.Score || player.Score == dealer.Score) //tie
            {
               // Console.WriteLine();
                Console.SetCursorPosition(0, 18);
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Tie!");
                Console.ResetColor();
            }
            else if (dealer.Score > 21 && player.Score < 21) //dealer bust
            {
                //Console.WriteLine();
                Console.SetCursorPosition(0, 18);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Dealer Busted!");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(" Player Wins!");
                Console.ResetColor();
            }
            else if (player.Score > 21) //player bust
            {
                //Console.WriteLine();
                Console.SetCursorPosition(0, 18);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Player has busted!");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(" Dealer Wins!");
                Console.ResetColor();
            }
            else if (dealer.Score > player.Score && player.Score < 21 && dealer.Score != 21) //checks to see if dealer score is greater then player score and that player did not bust
            {
                //Console.WriteLine();
                Console.SetCursorPosition(0, 18);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Dealer wins! ");
                Console.ResetColor();
            }
            else if (player.Score > dealer.Score && player.Score != 21) //checks to see if player score is greater then dealer score and dealer did not bust
            {
                //Console.WriteLine();
                Console.SetCursorPosition(0, 18);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Player Wins! ");
                Console.ResetColor();
            }
            else if (player.Score == 21) //player blackjack
            {
                Console.SetCursorPosition(0, 18);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Blackjack! Player Wins!");
                Console.ResetColor();
            }
            else if (dealer.Score == 21) //dealer blackjack
            {
                Console.SetCursorPosition(0, 18);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Blackjack! Dealer Wins!");
                Console.ResetColor();
            }
            #endregion
        }//end of play round method
    }
}
//&& dealer.Score< 21