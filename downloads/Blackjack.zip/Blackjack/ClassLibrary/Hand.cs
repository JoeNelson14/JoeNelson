﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Hand
    {
        protected List<ICard> _cards = new List<ICard>();
        public virtual void AddCard(ICard card)
        {
            _cards.Add(card);
        }
        public virtual void Draw(int x, int y)
        {
            //draws cards at certain postions in console
            for (int i = 0; i < _cards.Count; i++)
            {
                //calls to Draw method in CardClass to make graphics of cards & moves x 10 positions over for next card
                _cards[i].Draw(x, y);
                x += 10;
            }
        }
    }
}
