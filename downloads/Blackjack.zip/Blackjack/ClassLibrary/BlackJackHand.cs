﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BlackJackHand : Hand
    {
        public int Score { get; private set; }
        public bool IsDealer { get; set; }

        public BlackJackHand (bool isDealer = false)
        {
            IsDealer = isDealer;
        }
        public override void AddCard(ICard card)
        {
            base.AddCard(card);
            Score = 0;
            
            //add value of players hand to score
            foreach (BlackjackCard item in _cards)
            {
                Score += item.Value;
            }

            //if score is greater then 21, it loops through the players hand and changes each ace to 1 until score is below 21
            if (Score > 21)
            {
                foreach (BlackjackCard item in _cards)
                {
                    //checks to see if value of card is equal to 11
                    if (item.Value == 11)
                    {
                        //sets value of ace to 1 and take 10 away from score
                        item.Value = 1;
                        Score -= 10;
                        break;
                    } 
                }
            }
        }

        public override void Draw (int x, int y)
        {
            //hides the first card of dealer
            if (IsDealer == true)
            {
                
                //Score = 0;
                Console.SetCursorPosition(0, 0);
                //Console.WriteLine($"Dealer Score: {Score}");
                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.White;
                Console.SetCursorPosition(0, y + 2);
                Console.WriteLine("   ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            else
            {
                _cards.First().Draw(0,2);
            }
            //Console.WriteLine();
        }
    }
}
