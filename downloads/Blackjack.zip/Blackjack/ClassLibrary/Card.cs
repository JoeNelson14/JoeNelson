﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public enum CardSuit
    {
        Spades = 1,
        Hearts,
        Clubs,
        Diamonds
    }
    public enum CardFace
    {
        Ace = 1,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King
    }
    public class Card : ICard
    {
        public Card(CardSuit suit, CardFace face)
        {
            Face = face;
            Suit = suit;
        }

        public CardSuit Suit { get; private set; }
        public CardFace Face { get; private set; }

        public void Draw(int x, int y)
        {
            Console.SetCursorPosition(x, y);

            switch (Suit)
            {
                case CardSuit.Spades: //writes spade symbol for card and sets color to symbol
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write("♠");                   
                    break;
                case CardSuit.Hearts: //writes heart symbol for card and sets color to symbol
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("♥");                   
                    break;
                case CardSuit.Clubs: //writes club symbol for card and sets color to symbol
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write("♣");                  
                    break;
                case CardSuit.Diamonds: //writes diamond symbol for card and sets color to symbol
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("♦");
                    break;
            }

            //Displays the letter/number of the card
            switch (Face)
            {
                case CardFace.Ace:
                    Console.Write("A ");
                    break;
                case CardFace.Two:
                    Console.Write("2 ");
                    break;
                case CardFace.Three:
                    Console.Write("3 ");
                    break;
                case CardFace.Four:
                    Console.Write("4 ");
                    break;
                case CardFace.Five:
                    Console.Write("5 ");
                    break;
                case CardFace.Six:
                    Console.Write("6 ");
                    break;
                case CardFace.Seven:
                    Console.Write("7 ");
                    break;
                case CardFace.Eight:
                    Console.Write("8 ");
                    break;
                case CardFace.Nine:
                    Console.Write("9 ");
                    break;
                case CardFace.Ten:
                    Console.Write("10");
                    break;
                case CardFace.Jack:
                    Console.Write("J ");
                    break;
                case CardFace.Queen:
                    Console.Write("Q ");
                    break;
                case CardFace.King:
                    Console.Write("K ");
                    break;
            }

            //writes spaces 4 down for card (y)
            for (int i = 0; i < 5; i++)
            {
                //when i = 0 writes space string with one less for symbole to fit on card and align it correctly and sets color to card
                if (i == 0)
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.WriteLine("     ");
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.CursorLeft = x;
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Write("");
                    Console.BackgroundColor = ConsoleColor.Black;
                }
                else //when i = 1,2,3 writes space string normally for card graphic also sets color to card
                {
                   
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.WriteLine("        ");
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.CursorLeft = x;
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Write("");
                    Console.BackgroundColor = ConsoleColor.Black;
                }
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
