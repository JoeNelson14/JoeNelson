﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Deck
    {
        List<ICard> _cards = new List<ICard>();
        public Deck()
        {
            createDeckAll();
            
        }
        public void createDeckAll()
        {
            for (int i = 1; i <= 4; i++)
            {
                for (int j = 1; j <= 13; j++)
                {
                    _cards.Add(Factory.CreateBlackjackCard((CardSuit)i, (CardFace)j));
                }
            }
        }
        public ICard Deal()
        {
            ICard deckEmpty = _cards[0];
            _cards.RemoveAt(0);
            if (_cards.Count <= 0)
            {
                createDeckAll();
            }
           
            return deckEmpty;
        }
        public void Shuffle()
        {
            //creates new temp list for cards
            List<ICard> tempList = new List<ICard>();
            Random rng = new Random();
            
            while (_cards.Count > 0)
           {
                //adds new random cards in _cards list and removes them at int a position
                int a = rng.Next(0, _cards.Count);
                tempList.Add(_cards[a]);
                _cards.RemoveAt(a);
            }
            //puts the new shuffled deck thats in tempList into original _cards list
            _cards = tempList;
        }
    }
}
