﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoeNelsonGOL
{
    public partial class Options : Form
    {
        public Options()
        {
            InitializeComponent();
        }
        public int GetTimeVal() //timer getter
        {
            return (int)timerIntervalUpDown.Value; //returns timer value user input
        }
        public void SetTimeVal(int timeVal) //timer setter
        {
            timerIntervalUpDown.Value = timeVal; //sets timer interval value
        }
        public int GetWidth() //grid width getter
        {
            return (int)uniWidthUpDown.Value; //returns univer width value from user
        }
        public void SetWidth(int uniWidth) //grid width setter
        {
            uniWidthUpDown.Value = uniWidth; //sets universe width value
        }
        public int GetHeight() //grid height getter
        {
            return (int)uniHeightUpDown.Value; //returns univer height value from user
        }
        public void SetHeight(int uniHeight) //grid height setter
        {
            uniHeightUpDown.Value = uniHeight; //sets universe height value
        }
    }
}
