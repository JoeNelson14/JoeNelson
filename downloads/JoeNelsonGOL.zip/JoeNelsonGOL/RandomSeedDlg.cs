﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoeNelsonGOL
{
    public partial class RandomSeedDlg : Form
    {
        int randySeed = 0;
        public RandomSeedDlg()
        {
            InitializeComponent();

        }

        private void RandomButton_Click(object sender, EventArgs e)
        {
            randySeed = new Random().Next(int.MinValue, int.MaxValue);
            RandomUpDown.Value = randySeed;
        }
        public int GetSeed()
        {
            return randySeed;
        }
    }
}
