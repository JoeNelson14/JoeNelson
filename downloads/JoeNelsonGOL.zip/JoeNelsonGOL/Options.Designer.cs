﻿namespace JoeNelsonGOL
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timerIntervalUpDown = new System.Windows.Forms.NumericUpDown();
            this.uniWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.uniHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.optionOkButton = new System.Windows.Forms.Button();
            this.optionCancelButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.timerIntervalUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniHeightUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Timer Interval in Milliseconds";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width of Universe in Cells";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Height of Universe in Cells";
            // 
            // timerIntervalUpDown
            // 
            this.timerIntervalUpDown.Location = new System.Drawing.Point(160, 7);
            this.timerIntervalUpDown.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.timerIntervalUpDown.Name = "timerIntervalUpDown";
            this.timerIntervalUpDown.Size = new System.Drawing.Size(120, 20);
            this.timerIntervalUpDown.TabIndex = 3;
            // 
            // uniWidthUpDown
            // 
            this.uniWidthUpDown.Location = new System.Drawing.Point(160, 40);
            this.uniWidthUpDown.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.uniWidthUpDown.Name = "uniWidthUpDown";
            this.uniWidthUpDown.Size = new System.Drawing.Size(120, 20);
            this.uniWidthUpDown.TabIndex = 4;
            // 
            // uniHeightUpDown
            // 
            this.uniHeightUpDown.Location = new System.Drawing.Point(160, 75);
            this.uniHeightUpDown.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.uniHeightUpDown.Name = "uniHeightUpDown";
            this.uniHeightUpDown.Size = new System.Drawing.Size(120, 20);
            this.uniHeightUpDown.TabIndex = 5;
            // 
            // optionOkButton
            // 
            this.optionOkButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.optionOkButton.Location = new System.Drawing.Point(65, 114);
            this.optionOkButton.Name = "optionOkButton";
            this.optionOkButton.Size = new System.Drawing.Size(75, 23);
            this.optionOkButton.TabIndex = 6;
            this.optionOkButton.Text = "OK";
            this.optionOkButton.UseVisualStyleBackColor = true;
            // 
            // optionCancelButton
            // 
            this.optionCancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.optionCancelButton.Location = new System.Drawing.Point(160, 114);
            this.optionCancelButton.Name = "optionCancelButton";
            this.optionCancelButton.Size = new System.Drawing.Size(75, 23);
            this.optionCancelButton.TabIndex = 7;
            this.optionCancelButton.Text = "Cancel";
            this.optionCancelButton.UseVisualStyleBackColor = true;
            // 
            // Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 154);
            this.Controls.Add(this.optionCancelButton);
            this.Controls.Add(this.optionOkButton);
            this.Controls.Add(this.uniHeightUpDown);
            this.Controls.Add(this.uniWidthUpDown);
            this.Controls.Add(this.timerIntervalUpDown);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Options";
            this.Text = "Options";
            ((System.ComponentModel.ISupportInitialize)(this.timerIntervalUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniHeightUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown timerIntervalUpDown;
        private System.Windows.Forms.NumericUpDown uniWidthUpDown;
        private System.Windows.Forms.NumericUpDown uniHeightUpDown;
        private System.Windows.Forms.Button optionOkButton;
        private System.Windows.Forms.Button optionCancelButton;
    }
}