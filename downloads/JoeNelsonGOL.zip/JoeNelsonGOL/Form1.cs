﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace JoeNelsonGOL
{
    public partial class Form1 : Form
    {
        // The universe array
        bool[,] universe = new bool[Properties.Settings.Default.XValue, Properties.Settings.Default.YValue];
        bool checkBoundary = false;
        bool showNeighbor = true;

        // Drawing colors
        Color gridColor = Color.Black;
        Color cellColor = Color.Gray;

        // The Timer class
        Timer timer = new Timer();

        // Generation, seed, livingCell count
        int generations = 0;
        int seed = 0;
        int livingCells = 0;

        #region Form1 & Next Generation & Timer Tick
        public Form1()
        {
            InitializeComponent();

            // Setup the timer
            timer.Tick += Timer_Tick;
            timer.Enabled = false; // start timer running

            finiteToolStripMenuItem.Checked = true; //defaults to finite, finite is checked in tool strip at program start
            boundaryTypeLabel.Text = "Boundary Type: Finite"; //sets finite to default text since finite is default enabled
            gridSizeLabel.Text = $"Grid Size: [Width= {universe.GetLength(0)}, Height= {universe.GetLength(1)}]"; //sets grid size label test to display default grid size on start up
            intervalToolStrip.Text = "Interval: " + Properties.Settings.Default.TimerInterval;
            aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString();

            seedStripStatusLabel1.Text = "Seed: " + seed.ToString();

            //default settings
            gridColor = Properties.Settings.Default.GridColor;
            cellColor = Properties.Settings.Default.CellColor;
            graphicsPanel1.BackColor = Properties.Settings.Default.BackColor;
            universe = new bool[Properties.Settings.Default.XValue, Properties.Settings.Default.YValue];
            timer.Interval = Properties.Settings.Default.TimerInterval;

            //toggle starting checks
            toggleGridToolStripMenuItem.Checked = true;
            toggleHUDToolStripMenuItem.Checked = true;
            hUDToolStripMenuItem.Checked = true;
            gridToolStripMenuItem.Checked = true;
            neighborCountToolStripMenuItem.Checked = true;
            toggleNeighborCountToolStripMenuItem.Checked = true;
        }

        // Calculate the next generation of cells
        private void NextGeneration()
        {
            //variables
            bool[,] scratchPad = new bool[universe.GetLength(0), universe.GetLength(1)];
            int num = 0;
            livingCells = 0; //resets living cell count to 0 each generation

            seedStripStatusLabel1.Text = "Seed: " + seed.ToString();

            for (int x = 0; x < universe.GetLength(0); x++)
            {
                for (int y = 0; y < universe.GetLength(1); y++)
                {
                    scratchPad[x, y] = false;

                    //calls certain count neighbor method based on user selection in tool strip
                    if (!checkBoundary)
                    {
                        num = CountNeighborsFinite(x, y);
                    }
                    else
                    {
                        num = CountNeighborsToroidal(x, y);
                    }

                    if (universe[x, y] == true)
                    {
                        if (num >= 2 && num <= 3)
                        {
                            scratchPad[x, y] = true;
                            livingCells++;
                        }
                    }
                    else if (num == 3)
                    {
                        scratchPad[x, y] = true;
                        livingCells++;
                    }
                }
            }
            bool[,] temp = universe;
            universe = scratchPad;
            scratchPad = temp;

            // Increment generation count
            generations++;
            graphicsPanel1.Invalidate();

            //HUD Labels
            generationCountLabel.Text = "Generations: " + generations.ToString();
            cellCountLabel.Text = "Cell Count: " + livingCells.ToString();

            // Update status strip generations
            toolStripStatusLabelGenerations.Text = "Generations: " + generations.ToString();
            intervalToolStrip.Text = "Interval: " + timer.Interval.ToString();
            aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString();

            //checks which boundary type is enabled and displays currently enabled boundary type
            if (finiteToolStripMenuItem.Checked == this.Enabled)
            {
                boundaryTypeLabel.Text = "Boundary Type: Finite";
            }
            else if (toridialToolStripMenuItem.Checked == this.Enabled)
            {
                boundaryTypeLabel.Text = "Boundary Type: Toridal";
            }

            gridSizeLabel.Text = $"Grid Size: [Width= {universe.GetLength(0)}, Height= {universe.GetLength(1)}]";
        }

        // The event called by the timer every Interval milliseconds.
        private void Timer_Tick(object sender, EventArgs e)
        {
            NextGeneration();
        }
        #endregion

        #region Graphcis panel Paint & Click
        private void graphicsPanel1_Paint(object sender, PaintEventArgs e)
        {
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            int num = 0;

            // Calculate the width and height of each cell in pixels
            // CELL WIDTH = WINDOW WIDTH / NUMBER OF CELLS IN X
            float cellWidth = (float)graphicsPanel1.ClientSize.Width / (float)universe.GetLength(0);
            // CELL HEIGHT = WINDOW HEIGHT / NUMBER OF CELLS IN Y
            float cellHeight = (float)graphicsPanel1.ClientSize.Height / (float)universe.GetLength(1);

            // A Pen for drawing the grid lines (color, width)
            Pen gridPen = new Pen(gridColor, 1);
            Pen numPen = new Pen(gridColor, 2);

            // A Brush for filling living cells interiors (color)
            Brush cellBrush = new SolidBrush(cellColor);

            //Drawing Numbers
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center; //aligns pen in center for x
            format.LineAlignment = StringAlignment.Center; //aligns pen in center for y
            Font font = new Font("Times New Roman", 15);


            // Iterate through the universe in the y, top to bottom
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                // Iterate through the universe in the x, left to right
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    // A rectangle to represent each cell in pixels
                    RectangleF cellRect = RectangleF.Empty;
                    cellRect.X = (float)(x * cellWidth);
                    cellRect.Y = (float)(y * cellHeight);
                    cellRect.Width = (float)cellWidth;
                    cellRect.Height = (float)cellHeight;

                    // Fill the cell with a brush if alive
                    if (universe[x, y] == true)
                    {
                        e.Graphics.FillRectangle(cellBrush, cellRect);
                    }

                    // Outline the cell with a pen
                    e.Graphics.DrawRectangle(gridPen, cellRect.X, cellRect.Y, cellRect.Width, cellRect.Height);

                    if (showNeighbor)
                    {
                        if (finiteToolStripMenuItem.Checked)
                        {
                            num = CountNeighborsFinite(x, y);
                        }
                        if (toridialToolStripMenuItem.Checked)
                        {
                            num = CountNeighborsToroidal(x, y);
                        }
                        if (num >= 1)
                        {
                            if (universe[x, y] == true)
                            {
                                if (num >= 2 && num <= 3)
                                {
                                    e.Graphics.DrawString(num.ToString(), font, Brushes.Green, cellRect, format); //draws number based off font, color, and alignment of brush
                                }
                                else
                                {
                                    e.Graphics.DrawString(num.ToString(), font, Brushes.Red, cellRect, format); //draws number based off font, color, and alignment of brush
                                }
                            }
                            else if (num == 3)
                            {
                                e.Graphics.DrawString(num.ToString(), font, Brushes.Green, cellRect, format); //draws number based off font, color, and alignment of brush
                            }
                            else
                            {
                                e.Graphics.DrawString(num.ToString(), font, Brushes.Red, cellRect, format); //draws number based off font, color, and alignment of brush
                            }
                        }

                    }
                }
            }

            // Cleaning up pens and brushes
            gridPen.Dispose();
            numPen.Dispose();
            cellBrush.Dispose();
        }

        private void graphicsPanel1_MouseClick(object sender, MouseEventArgs e)
        {
            // If the left mouse button was clicked
            if (e.Button == MouseButtons.Left)
            {
                // Calculate the width and height of each cell in pixels
                float cellWidth = (float)graphicsPanel1.ClientSize.Width / universe.GetLength(0);
                float cellHeight = (float)graphicsPanel1.ClientSize.Height / universe.GetLength(1);

                // Calculate the cell that was clicked in
                // CELL X = MOUSE X / CELL WIDTH
                float x = (float)e.X / cellWidth;
                // CELL Y = MOUSE Y / CELL HEIGHT
                float y = (float)e.Y / cellHeight;

                // Toggle the cell's state
                universe[(int)x, (int)y] = !universe[(int)x, (int)y];

                // Tell Windows you need to repaint
                graphicsPanel1.Invalidate();

                //updates living cell count based on mouse clicking of grid
                if (universe[(int)x, (int)y])
                {
                    livingCells++;
                }
                else
                {
                    livingCells--;
                }

                //updates cell count hud per click
                cellCountLabel.Text = "Cell Count: " + livingCells.ToString();
                aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString();
            }
        }
        #endregion

        #region Count Neighbors Methods
        private int CountNeighborsFinite(int x, int y)
        {
            int count = 0;
            int xLen = universe.GetLength(0);
            int yLen = universe.GetLength(1);

            for (int yOffset = -1; yOffset <= 1; yOffset++)
            {
                for (int xOffset = -1; xOffset <= 1; xOffset++)
                {
                    int xCheck = x + xOffset;
                    int yCheck = y + yOffset;

                    // if xOffset and yOffset are both equal to 0 then continue
                    if (xOffset == 0 && yOffset == 0)
                    {
                        continue;
                    }
                    else if (xCheck < 0 || yCheck < 0) // if xCheck is less than 0 then continue, if yCheck is less than 0 then continue
                    {
                        continue;
                    }
                    else if ((xCheck >= xLen) || (yCheck >= yLen)) // if xCheck is greater than or equal too xLen then continue, if yCheck is greater than or equal too yLen then continue
                    {
                        continue;
                    }

                    if (universe[xCheck, yCheck] == true) count++;
                }
            }

            return count;
        }

        private int CountNeighborsToroidal(int x, int y)
        {
            int count = 0;
            int xLen = universe.GetLength(0);
            int yLen = universe.GetLength(1);

            for (int yOffset = -1; yOffset <= 1; yOffset++)
            {
                for (int xOffset = -1; xOffset <= 1; xOffset++)
                {
                    int xCheck = x + xOffset;
                    int yCheck = y + yOffset;

                    // if xOffset and yOffset are both equal to 0 then continue
                    if (xOffset == 0 && yOffset == 0)
                    {
                        continue;
                    }
                    if (xCheck < 0) // if xCheck is less than 0 then set to xLen - 1
                    {
                        xCheck = xLen - 1;
                    }
                    if (yCheck < 0) // if yCheck is less than 0 then set to yLen - 1
                    {
                        yCheck = yLen - 1;
                    }
                    if (xCheck >= xLen) // if xCheck is greater than or equal too xLen then set to 0
                    {
                        xCheck = 0;
                    }
                    if (yCheck >= yLen) // if yCheck is greater than or equal too yLen then set to 0
                    {
                        yCheck = 0;
                    }

                    if (universe[xCheck, yCheck] == true) count++;
                }
            }
            return count;
        }
        #endregion

        #region New, Play, Pause, Next tool strip
        //Start button
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            timer.Enabled = true;
        }

        //Pause button
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            timer.Enabled = false;
        }

        //Next Button
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            NextGeneration();
        }

        //New Button
        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    universe[x, y] = false; //clears graphics panel of cells by turning off universe
                }
            }
            timer.Enabled = false; //turns off timer when new is clicked
            generations = 0; //sets generations to 0
            livingCells = 0; //sets living cells to 0
            toolStripStatusLabelGenerations.Text = "Generations = " + generations.ToString(); //updates generation tool strip status when new is clicked

            //updates labels when new is clicked
            generationCountLabel.Text = "Generations: " + generations.ToString();
            cellCountLabel.Text = "Cell Count: " + livingCells.ToString();
            boundaryTypeLabel.Text = "Boudary Type: Finite";
            aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString();

            graphicsPanel1.Invalidate();
        }
        #endregion

        #region Boundary type tool strips
        //toridal button
        private void toridialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toridialToolStripMenuItem.Checked) //checks ot see if toridial is checked
            {
                boundaryTypeLabel.Text = "Boundary Type: Tororidal";
                toridialToolStripMenuItem.Enabled = true; //sets toridial to enable
                finiteToolStripMenuItem.Enabled = false; //sets finite to disabled, so only one can be enabled at a time
            }
            if (!checkBoundary)
            {
                boundaryTypeLabel.Text = "Boundary Type: Tororidal";
                checkBoundary = true; //sets bool to true so toridal can be activated in next generation method
                toridialToolStripMenuItem.Checked = true; //sets toridial to enable
                finiteToolStripMenuItem.Checked = false; //sets finite to disabled, so only one can be enabled at a time
            }
            graphicsPanel1.Invalidate();
        }

        //finite button
        private void finiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (finiteToolStripMenuItem.Checked)
            {
                boundaryTypeLabel.Text = "Boundary Type: Finite";
                finiteToolStripMenuItem.Enabled = true; //sets finite to enable
                toridialToolStripMenuItem.Enabled = false; //sets toridial to disabled, so only one can be enabled at a time
            }
            if (checkBoundary)
            {
                boundaryTypeLabel.Text = "Boundary Type: Finite";
                checkBoundary = false; //sets bool to false so finite can be activated in nex geration method
                finiteToolStripMenuItem.Checked = true; //sets finite to enable
                toridialToolStripMenuItem.Checked = false;//sets toridial to disabled, so only one can be enabled at a time=
            }
            graphicsPanel1.Invalidate();
        }
        #endregion

        #region Randomize tool strips
        //random seed generator button
        private void seedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RandomSeedDlg rngSeed = new RandomSeedDlg();
            if (DialogResult.OK == rngSeed.ShowDialog())
            {
                seed = rngSeed.GetSeed(); //gets randomized seed that was generated
                Random rng = new Random(seed); //generates random number
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    for (int y = 0; y < universe.GetLength(1); y++)
                    {
                        universe[x, y] = false;
                        if (rng.Next(0, 4) == 0)
                        {
                            universe[x, y] = true;
                            livingCells++;
                        }
                    }
                }
            }
            generations = 0;
            generationCountLabel.Text = "Generations: " + generations.ToString();
            cellCountLabel.Text = "Cell Count: " + livingCells.ToString();
            aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString();
            seedStripStatusLabel1.Text = "Seed: " + seed.ToString();
            timer.Enabled = false;
            graphicsPanel1.Invalidate();
        }
        private void currentSeedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random rng = new Random(); //gerates random number
            for (int x = 0; x < universe.GetLength(0); x++)
            {
                for (int y = 0; y < universe.GetLength(1); y++)
                {
                    universe[x, y] = false;
                    if (rng.Next(0, 5) == 0)
                    {
                        universe[x, y] = true;
                        livingCells++;
                    }
                }
            }
            generations = 0;
            generationCountLabel.Text = "Generations: " + generations.ToString();
            cellCountLabel.Text = "Cell Count: " + livingCells.ToString();
            aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString();
            timer.Enabled = false;
            graphicsPanel1.Invalidate();
        }
        private void timeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RandomSeedDlg randomSeed = new RandomSeedDlg();
            Random rng = new Random(DateTime.Now.Second); //generates random number based of computer time in secons

            for (int x = 0; x < universe.GetLength(0); x++)
            {
                for (int y = 0; y < universe.GetLength(0); y++)
                {
                    universe[x, y] = false;
                    if (rng.Next(0, 4) == 0)
                    {
                        universe[x, y] = true;
                        livingCells++;
                    }
                }
            }
            generations = 0;
            seed = randomSeed.GetSeed();
            generationCountLabel.Text = "Generations: " + generations.ToString();
            cellCountLabel.Text = "Cell Count: " + livingCells.ToString();
            aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString();
            seedStripStatusLabel1.Text = "Seed: " + seed.ToString();
            timer.Enabled = false;

            graphicsPanel1.Invalidate();
        }
        #endregion

        #region Color tool strips
        private void backColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //instances of ColorDialog
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.Color = graphicsPanel1.BackColor;
            if (DialogResult.OK != colorDlg.ShowDialog())
                return;
            graphicsPanel1.BackColor = colorDlg.Color;
            graphicsPanel1.Invalidate();
        }

        private void cellColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.Color = cellColor;
            if (DialogResult.OK != colorDlg.ShowDialog())
                return;
            cellColor = colorDlg.Color;
            graphicsPanel1.Invalidate();
        }

        private void gridColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.Color = gridColor;
            if (DialogResult.OK != colorDlg.ShowDialog())
                return;
            gridColor = colorDlg.Color;
            graphicsPanel1.Invalidate();
        }
        #endregion

        #region Toggles & Option tool strip
        private void toggleGridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toggleGridToolStripMenuItem.Checked)
            {
                toggleGridToolStripMenuItem.Checked = false;
                gridToolStripMenuItem.Checked = false;
                gridColor = Color.Transparent;
                graphicsPanel1.Invalidate();
                return;
            }
            if (!toggleGridToolStripMenuItem.Checked)
            {
                toggleGridToolStripMenuItem.Checked = true;
                gridToolStripMenuItem.Checked = true;
                gridColor = Properties.Settings.Default.GridColor;
                graphicsPanel1.Invalidate();
            }
        }
        private void toggleHUDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toggleHUDToolStripMenuItem.Checked)
            {
                toggleHUDToolStripMenuItem.Checked = false;
                hUDToolStripMenuItem.Checked = false;
                generationCountLabel.Visible = false;
                cellCountLabel.Visible = false;
                boundaryTypeLabel.Visible = false;
                gridSizeLabel.Visible = false;
                graphicsPanel1.Invalidate();
                return;
            }
            if (!toggleHUDToolStripMenuItem.Checked)
            {
                toggleHUDToolStripMenuItem.Checked = true;
                hUDToolStripMenuItem.Checked = true;
                generationCountLabel.Visible = true;
                cellCountLabel.Visible = true;
                boundaryTypeLabel.Visible = true;
                gridSizeLabel.Visible = true;
                graphicsPanel1.Invalidate();
            }
        }
        private void toggleNeighborCountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toggleNeighborCountToolStripMenuItem.Checked)
            {
                showNeighbor = false;
                toggleNeighborCountToolStripMenuItem.Checked = false;
                neighborCountToolStripMenuItem.Checked = false;
                graphicsPanel1.Invalidate();
                return;
            }
            if (!toggleNeighborCountToolStripMenuItem.Checked)
            {
                showNeighbor = true;
                toggleNeighborCountToolStripMenuItem.Checked = true;
                neighborCountToolStripMenuItem.Checked = true;
                graphicsPanel1.Invalidate();
            }
        }
        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Options optionDlg = new Options();
            optionDlg.SetTimeVal(timer.Interval); //sets default value in num box to current number
            optionDlg.SetWidth(universe.GetLength(0)); //sets default value in num box to current universe width
            optionDlg.SetHeight(universe.GetLength(1)); //sets default value in num box to current universe height
            if (DialogResult.OK == optionDlg.ShowDialog())
            {
                timer.Interval = optionDlg.GetTimeVal(); //sets time interval to user input
                universe = new bool[optionDlg.GetWidth(), optionDlg.GetHeight()]; //sets universe to user input
            }
            livingCells = 0; //resets living cell count to 0
            intervalToolStrip.Text = "Interval: " + timer.Interval.ToString(); //updates interval text
            gridSizeLabel.Text = $"Grid Size: [Width= {universe.GetLength(0)}, Height= {universe.GetLength(1)}]"; //update universe count text
            cellCountLabel.Text = "Cell Count: " + livingCells.ToString(); //updates cell count text
            aliveCellsStripStatusLabel1.Text = "Alive: " + livingCells.ToString(); //updates alive count text
            graphicsPanel1.Invalidate();
        }
        #endregion

        #region Context Menu Strip
        private void backColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //instances of ColorDialog
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.Color = graphicsPanel1.BackColor;
            if (DialogResult.OK != colorDlg.ShowDialog())
                return;
            graphicsPanel1.BackColor = colorDlg.Color;
            graphicsPanel1.Invalidate();
        }
        private void cellColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.Color = cellColor;
            if (DialogResult.OK != colorDlg.ShowDialog())
                return;
            cellColor = colorDlg.Color;
            graphicsPanel1.Invalidate();
        }
        private void gridColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.Color = gridColor;
            if (DialogResult.OK != colorDlg.ShowDialog())
                return;
            gridColor = colorDlg.Color;
            graphicsPanel1.Invalidate();
        }
        private void hUDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toggleHUDToolStripMenuItem.Checked)
            {
                toggleHUDToolStripMenuItem.Checked = false;
                hUDToolStripMenuItem.Checked = false;
                generationCountLabel.Visible = false;
                cellCountLabel.Visible = false;
                boundaryTypeLabel.Visible = false;
                gridSizeLabel.Visible = false;
                graphicsPanel1.Invalidate();
                return;
            }
            if (!toggleHUDToolStripMenuItem.Checked)
            {
                toggleHUDToolStripMenuItem.Checked = true;
                hUDToolStripMenuItem.Checked = true;
                generationCountLabel.Visible = true;
                cellCountLabel.Visible = true;
                boundaryTypeLabel.Visible = true;
                gridSizeLabel.Visible = true;
                graphicsPanel1.Invalidate();
            }
        }
        private void neighborCountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toggleNeighborCountToolStripMenuItem.Checked)
            {
                showNeighbor = false;
                toggleNeighborCountToolStripMenuItem.Checked = false;
                neighborCountToolStripMenuItem.Checked = false;
                graphicsPanel1.Invalidate();
                return;
            }
            if (!toggleNeighborCountToolStripMenuItem.Checked)
            {
                showNeighbor = true;
                toggleNeighborCountToolStripMenuItem.Checked = true;
                neighborCountToolStripMenuItem.Checked = true;
                graphicsPanel1.Invalidate();
            }
        }
        private void gridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toggleGridToolStripMenuItem.Checked)
            {
                toggleGridToolStripMenuItem.Checked = false;
                gridToolStripMenuItem.Checked = false;
                gridColor = Color.Transparent;
                graphicsPanel1.Invalidate();
                return;
            }
            if (!toggleGridToolStripMenuItem.Checked)
            {
                toggleGridToolStripMenuItem.Checked = true;
                gridToolStripMenuItem.Checked = true;
                gridColor = Properties.Settings.Default.GridColor;
                graphicsPanel1.Invalidate();
            }
        }
        #endregion

        #region Save & Open file
        private void saveToolStripMenuItem_Click(object sender, EventArgs e) //save tool stip menu
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "All Files|*.*|Cells|*.cells";
            dlg.FilterIndex = 2; dlg.DefaultExt = "cells";

            if (DialogResult.OK == dlg.ShowDialog())
            {
                using (StreamWriter sw = new StreamWriter(dlg.FileName))
                {
                    // Iterate through the universe one row at a time.
                    for (int y = 0; y < universe.GetLength(1); y++)
                    {
                        // Create a string to represent the current row.
                        string currentRow = string.Empty;
                        for (int x = 0; x < universe.GetLength(0); x++)
                        {
                            // If the universe[x,y] is alive then append 'O' (capital O) to the row string.
                            if (universe[x, y])
                                sw.Write("O");
                            else if (!universe[x, y])
                                sw.Write(".");
                        }
                        sw.WriteLine(currentRow);
                    }
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "All Files|*.*|Cells|*.cells";
            dlg.FilterIndex = 2;

            if (DialogResult.OK == dlg.ShowDialog())
            {
                using (StreamReader reader = new StreamReader(dlg.FileName))
                {
                    // Create a couple variables to calculate the width and height
                    // of the data in the file.
                    int maxWidth = 0;
                    int maxHeight = 0;

                    // Iterate through the file once to get its size.
                    while (!reader.EndOfStream)
                    {
                        // Read one row at a time.
                        string row = reader.ReadLine();

                        // If the row is not a comment then it is a row of cells.
                        // Increment the maxHeight variable for each row read.
                        if (row[0] != '!')
                        {
                            maxHeight++;
                            // Get the length of the current row string
                            // and adjust the maxWidth variable if necessary.
                            if (row.Length > maxWidth)
                                maxWidth = row.Length;
                        }

                    }

                    // Resize the current universe and scratchPad
                    // to the width and height of the file calculated above.
                    universe = new bool[maxWidth, maxHeight];
                    // Reset the file pointer back to the beginning of the file.
                    reader.BaseStream.Seek(0, SeekOrigin.Begin);
                    int yPos = 0;
                    // Iterate through the file again, this time reading in the cells.
                    while (!reader.EndOfStream)
                    {
                        // Read one row at a time.
                        string row = reader.ReadLine();

                        // If the row is not a comment then 
                        // it is a row of cells and needs to be iterated through.
                        if (row[0] != '!')
                        {
                            maxHeight++;
                            // Get the length of the current row string
                            // and adjust the maxWidth variable if necessary.
                            if (row.Length > maxWidth)
                                maxWidth = row.Length;
                        }
                        for (int xPos = 0; xPos < row.Length; xPos++)
                        {
                            // If row[xPos] is a 'O' (capital O) then
                            // set the corresponding cell in the universe to alive.
                            if (row[xPos] == 'O')
                                universe[xPos, yPos] = true;
                            // If row[xPos] is a '.' (period) then
                            // set the corresponding cell in the universe to dead.
                            if (row[xPos] == '.')
                                universe[xPos, yPos] = false;
                            graphicsPanel1.Invalidate();
                        }
                        yPos++;
                    }
                }
            }
        }
        private void saveToolStripButton_Click(object sender, EventArgs e) //save tool stip icon
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "All Files|*.*|Cells|*.cells";
            dlg.FilterIndex = 2; dlg.DefaultExt = "cells";

            if (DialogResult.OK == dlg.ShowDialog())
            {
                using (StreamWriter sw = new StreamWriter(dlg.FileName))
                {
                    // Iterate through the universe one row at a time.
                    for (int y = 0; y < universe.GetLength(1); y++)
                    {
                        // Create a string to represent the current row.
                        string currentRow = string.Empty;
                        for (int x = 0; x < universe.GetLength(0); x++)
                        {
                            // If the universe[x,y] is alive then append 'O' (capital O) to the row string.
                            if (universe[x, y])
                                sw.Write("O");
                            else if (!universe[x, y])
                                sw.Write(".");
                        }
                        sw.WriteLine(currentRow);
                    }
                }
            }
        }
        private void openToolStripButton_Click(object sender, EventArgs e) //open tool stip icon
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "All Files|*.*|Cells|*.cells";
            dlg.FilterIndex = 2;

            if (DialogResult.OK == dlg.ShowDialog())
            {
                using (StreamReader reader = new StreamReader(dlg.FileName))
                {
                    // Create a couple variables to calculate the width and height
                    // of the data in the file.
                    int maxWidth = 0;
                    int maxHeight = 0;

                    // Iterate through the file once to get its size.
                    while (!reader.EndOfStream)
                    {
                        // Read one row at a time.
                        string row = reader.ReadLine();

                        // If the row is not a comment then it is a row of cells.
                        // Increment the maxHeight variable for each row read.
                        if (row[0] != '!')
                        {
                            maxHeight++;
                            // Get the length of the current row string
                            // and adjust the maxWidth variable if necessary.
                            if (row.Length > maxWidth)
                                maxWidth = row.Length;
                        }

                    }

                    // Resize the current universe and scratchPad
                    // to the width and height of the file calculated above.
                    universe = new bool[maxWidth, maxHeight];
                    // Reset the file pointer back to the beginning of the file.
                    reader.BaseStream.Seek(0, SeekOrigin.Begin);
                    int yPos = 0;
                    // Iterate through the file again, this time reading in the cells.
                    while (!reader.EndOfStream)
                    {
                        // Read one row at a time.
                        string row = reader.ReadLine();

                        // If the row is not a comment then 
                        // it is a row of cells and needs to be iterated through.
                        if (row[0] != '!')
                        {
                            maxHeight++;
                            // Get the length of the current row string
                            // and adjust the maxWidth variable if necessary.
                            if (row.Length > maxWidth)
                                maxWidth = row.Length;
                        }
                        for (int xPos = 0; xPos < row.Length; xPos++)
                        {
                            // If row[xPos] is a 'O' (capital O) then
                            // set the corresponding cell in the universe to alive.
                            if (row[xPos] == 'O')
                                universe[xPos, yPos] = true;
                            // If row[xPos] is a '.' (period) then
                            // set the corresponding cell in the universe to dead.
                            if (row[xPos] == '.')
                                universe[xPos, yPos] = false;
                            graphicsPanel1.Invalidate();
                        }
                        yPos++;
                    }
                }
            }
        }

        #endregion

        #region Settings Closing, Reset, Reload
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //stores users changes from default settings on close
            Properties.Settings.Default.BackColor = graphicsPanel1.BackColor;
            Properties.Settings.Default.GridColor = gridColor;
            Properties.Settings.Default.CellColor = cellColor;
            Properties.Settings.Default.XValue = universe.GetLength(0);
            Properties.Settings.Default.YValue = universe.GetLength(1);
            Properties.Settings.Default.TimerInterval = timer.Interval;
            Properties.Settings.Default.Save(); //saves settings user has
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //resets all settings back to default with no changes from user
            Properties.Settings.Default.Reset();
            cellColor = Properties.Settings.Default.CellColor;
            graphicsPanel1.BackColor = Properties.Settings.Default.BackColor;
            gridColor = Properties.Settings.Default.GridColor;
            timer.Interval = Properties.Settings.Default.TimerInterval;
            universe = new bool[Properties.Settings.Default.XValue, Properties.Settings.Default.YValue];
            graphicsPanel1.Invalidate();
        }

        private void reloadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Reload();
            cellColor = Properties.Settings.Default.CellColor;
            gridColor = Properties.Settings.Default.GridColor;
            graphicsPanel1.BackColor = Properties.Settings.Default.BackColor;
            timer.Interval = Properties.Settings.Default.TimerInterval;
            universe = new bool[Properties.Settings.Default.XValue, Properties.Settings.Default.YValue];
            graphicsPanel1.Invalidate();
        }







        #endregion

        private void importToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDLG = new OpenFileDialog();
            openDLG.Filter = "All Files|*.*|Cells|*.cells";
            openDLG.FilterIndex = 2;
            if (DialogResult.OK == openDLG.ShowDialog())
            {
                using (StreamReader streamReader = new StreamReader(openDLG.FileName))
                {
                    int number1 = 0;
                    int number2 = 0;
                    //checks for commets
                    while (!streamReader.EndOfStream)
                    {
                        string str = streamReader.ReadLine();
                        if (str[0] != '!')
                        {
                            number2++;
                            if (str.Length > number1)
                                number1 = str.Length;
                        }
                    }
                    //importing
                    streamReader.BaseStream.Seek(0L, SeekOrigin.Begin);
                    int index1 = 0;
                    while (!streamReader.EndOfStream)
                    {
                        string str = streamReader.ReadLine();
                        if (str[0] != '!')
                        {
                            number2++;
                            if (str.Length > number1)
                                number1 = str.Length;
                        }
                        for (int index2 = 0; index2 < str.Length; ++index2)
                        {
                            if (str[index2] == 'O')
                                this.universe[index2, index1] = true;
                            if (str[index2] == '.')
                                this.universe[index2, index1] = false;
                            this.graphicsPanel1.Invalidate();
                        }
                        ++index1;
                    }
                }
            }
        }
    }//end class
}//end namespace
