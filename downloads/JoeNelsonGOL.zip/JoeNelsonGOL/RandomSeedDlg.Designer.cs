﻿namespace JoeNelsonGOL
{
    partial class RandomSeedDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RandomButton = new System.Windows.Forms.Button();
            this.OkRandomButton = new System.Windows.Forms.Button();
            this.CancelRandomButton = new System.Windows.Forms.Button();
            this.RandomUpDown = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.RandomUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // RandomButton
            // 
            this.RandomButton.Location = new System.Drawing.Point(138, 49);
            this.RandomButton.Name = "RandomButton";
            this.RandomButton.Size = new System.Drawing.Size(75, 23);
            this.RandomButton.TabIndex = 0;
            this.RandomButton.Text = "Randomize";
            this.RandomButton.UseVisualStyleBackColor = true;
            this.RandomButton.Click += new System.EventHandler(this.RandomButton_Click);
            // 
            // OkRandomButton
            // 
            this.OkRandomButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OkRandomButton.Location = new System.Drawing.Point(15, 104);
            this.OkRandomButton.Name = "OkRandomButton";
            this.OkRandomButton.Size = new System.Drawing.Size(75, 23);
            this.OkRandomButton.TabIndex = 1;
            this.OkRandomButton.Text = "OK";
            this.OkRandomButton.UseVisualStyleBackColor = true;
            // 
            // CancelRandomButton
            // 
            this.CancelRandomButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelRandomButton.Location = new System.Drawing.Point(138, 104);
            this.CancelRandomButton.Name = "CancelRandomButton";
            this.CancelRandomButton.Size = new System.Drawing.Size(75, 23);
            this.CancelRandomButton.TabIndex = 2;
            this.CancelRandomButton.Text = "Cancel";
            this.CancelRandomButton.UseVisualStyleBackColor = true;
            // 
            // RandomUpDown
            // 
            this.RandomUpDown.Location = new System.Drawing.Point(12, 49);
            this.RandomUpDown.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.RandomUpDown.Minimum = new decimal(new int[] {
            -2147483648,
            0,
            0,
            -2147483648});
            this.RandomUpDown.Name = "RandomUpDown";
            this.RandomUpDown.Size = new System.Drawing.Size(120, 20);
            this.RandomUpDown.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(212, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Press Randomize Button For Random Seed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Seed";
            // 
            // RandomSeedDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 139);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RandomUpDown);
            this.Controls.Add(this.CancelRandomButton);
            this.Controls.Add(this.OkRandomButton);
            this.Controls.Add(this.RandomButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RandomSeedDlg";
            this.Text = "Random Seed";
            ((System.ComponentModel.ISupportInitialize)(this.RandomUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RandomButton;
        private System.Windows.Forms.Button OkRandomButton;
        private System.Windows.Forms.Button CancelRandomButton;
        private System.Windows.Forms.NumericUpDown RandomUpDown;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}